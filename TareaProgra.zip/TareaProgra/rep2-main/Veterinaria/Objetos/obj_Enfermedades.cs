﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    public class obj_Enfermedades
    {
        public int IdMascota { get; set; }
        public String descripcion { get; set; }

        public obj_Enfermedades()
        {
        }

        public List<obj_Enfermedades> enfermedades = new List<obj_Enfermedades>();
        
    }
}
