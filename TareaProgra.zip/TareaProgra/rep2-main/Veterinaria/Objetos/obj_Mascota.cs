﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    public class obj_Mascota
    {
       public int idCliente { get; set; }
       public int idMascota { get; set; }
       public String NombreMasc { get; set; }
       public String TipoAnimal { get; set; }
       public String Raza { get; set; }
       public Double Peso { get; set; }
       public Double Medida { get; set; }

        public obj_Mascota()
        {
        }
        public List<obj_Mascota> mascotas = new List<obj_Mascota>();
    }

}
