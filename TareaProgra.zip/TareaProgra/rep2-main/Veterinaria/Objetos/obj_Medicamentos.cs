﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    public class obj_Medicamentos
    {
        public int IdMascota { get; set; }
        public string descripcion { get; set; }

        public obj_Medicamentos()
        {
        }

        public List<obj_Medicamentos> medicamentos = new List<obj_Medicamentos>();
        /*public String NombreMedic { get; set; }
public String DosisMedic { get; set; }
public String ViaAdministracion { get; set; }
public String Indicaciones { get; set; }
public String EfecSecundarios { get; set; }
public String FechaCaducidad { get; set; }*/
        /*Comamammamamam*/

    }
}
