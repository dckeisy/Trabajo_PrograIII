﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    public class obj_Cliente
    {
        public String Identificacion { get; set; }
        public String Nombre { get; set; }
        public String Apellidos { get; set;}
        public String Telefono { get; set; }
        public String Direccion { get; set; }
        public int idMascota { get; set; }

        public obj_Cliente()
        {
        }
        public List<obj_Cliente> clientes = new List<obj_Cliente>();
    }
}
