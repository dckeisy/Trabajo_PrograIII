﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objetos;

namespace Datos
{
    public class BDCliente
    {
        string archivo = @"C:\ArchivosTXT\clientes.txt";

        public void CrearTXT(List<obj_Cliente> clientes)
        {
            Verify();
            string rutaCarpeta = @"C:\ArchivosTXT";
            string a = Path.Combine(rutaCarpeta, "clientes.txt");
            if (File.Exists(a))
            {
                string nuevoContenido = string.Join("\n", clientes.Select(c => $"{c.Identificacion},{c.Nombre},{c.Apellidos},{c.Telefono},{c.Direccion}"));
                File.AppendAllText(a, nuevoContenido + "\n");
            }
            else
            {
                StringBuilder concatena = new StringBuilder();
                foreach (obj_Cliente c in clientes)
                {
                    concatena.Append(c.Identificacion + "," + c.Nombre + "," + c.Apellidos + "," + c.Telefono + "," + c.Direccion + "\n");
                }
                File.WriteAllText(a, concatena.ToString());
            }
        }
        public void Verify()
        {
            string rutaCarpeta = @"C:\ArchivosTXT";
            if (!Directory.Exists(rutaCarpeta))
            {
                Directory.CreateDirectory(rutaCarpeta);
            }
            string archivo = Path.Combine(rutaCarpeta, "clientes.txt");
        }

        public void LeerTXT()
        {
            string content = File.ReadAllText(archivo);
            Console.WriteLine(content);
        }
        public List<string> ObtenerID()
        {
            Verify();
            List<string> ids = new List<string>();

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    String[] temp = lineas[i].Split(',');
                    ids.Add(temp[0]);
                }
            }
            return ids;
        }
        public void Eliminar(string idCliente)
        {
            List<string> nuevaLinea = new List<string>();
            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    String[] temp = lineas[i].Split(',');
                    if (temp[0] !=idCliente)
                    {
                        nuevaLinea.Add(lineas[i]);
                    }
                }
                File.WriteAllLines(archivo, nuevaLinea);
            }
        }


    }
}
