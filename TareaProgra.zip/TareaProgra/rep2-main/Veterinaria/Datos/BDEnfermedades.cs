﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.MemoryMappedFiles;
using Objetos;
using System.IO;

namespace Datos
{
    public class BDEnfermedades
    {
        string archivo = @"C:\ArchivosTXT\enfermedades.txt";
        public void CrearTXT(List<obj_Enfermedades> enfermedades)
        {
            Verify();
            string rutaCarpeta = @"C:\ArchivosTXT";
            string a = Path.Combine(rutaCarpeta, "enfermedades.txt");
            if (File.Exists(a))
            {
                Modificar(enfermedades);
            }
            else
            {
                StringBuilder concatena = new StringBuilder();
                foreach (obj_Enfermedades e in enfermedades)
                {
                    concatena.Append(e.IdMascota + "," + e.descripcion + "\n");
                }
                File.WriteAllText(a, concatena.ToString());
            }
        }
        public void Modificar(List<obj_Enfermedades> enfermedades)
        {
            string[] lineas = File.ReadAllLines(archivo);
            
            foreach (obj_Enfermedades e in enfermedades)
            {
                int lineIndex = lineas
                .Select((line, index) => new { line, index })
                .FirstOrDefault(x => x.line.StartsWith(e.IdMascota + ","))
                ?.index ?? -1;

                if (lineIndex != -1)
                {
                    // Si la línea existe, modificarla
                    lineas[lineIndex] = $"{e.IdMascota},{e.descripcion}";
                }
                else
                {
                    // Si la línea no existe, agregar una nueva línea al final del archivo
                    lineas = lineas.Append($"{e.IdMascota},{e.descripcion}").ToArray();
                }
            }
            File.WriteAllLines(archivo, lineas);
            
        }
        public void Verify()
        {
            string rutaCarpeta = @"C:\ArchivosTXT";
            if (!Directory.Exists(rutaCarpeta))
            {
                Directory.CreateDirectory(rutaCarpeta);
            }
            string archivo = Path.Combine(rutaCarpeta, "enfermedades.txt");
        }
        public void LeerTXT()
        {
            string content = File.ReadAllText(archivo);
            Console.WriteLine(content);
        }
        public List<string> OptenerID()
        {
            List<string> ids = new List<string>();

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    String[] temp = lineas[i].Split(',');
                    if (ids.Contains(temp[1]))
                    {
                        //si ya esta en la lista no hace nada. Evita replicas
                    }
                    else
                    {
                        ids.Add(temp[0]);
                    }
                }
            }
            return ids;
        }
        public List<string> ObtenerDescripcion()
        {
            var descripciones = new HashSet<string>();

            if (File.Exists(archivo))
            {
                foreach (var linea in File.ReadAllLines(archivo))
                {
                    var temp = linea.Split(',');
                    if (temp.Length > 1)
                    {
                        descripciones.Add(temp[1]);
                    }
                }
            }

            return descripciones.ToList();
        }
        
        public static string[] ObtenerMascotaPorID(int idMascota)
        {
            if (File.Exists(@"C:\ArchivosTXT\enfermedades.txt"))
            {
                string[] lineas = File.ReadAllLines(@"C:\ArchivosTXT\enfermedades.txt");
                foreach (string linea in lineas)
                {
                    string[] campos = linea.Split(',');
                    if (Convert.ToInt32(campos[0]) == idMascota)
                    {
                        return campos;
                    }
                }
            }
            return null;
        }

    }
}

