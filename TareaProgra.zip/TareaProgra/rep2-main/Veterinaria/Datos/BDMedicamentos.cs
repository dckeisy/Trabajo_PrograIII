﻿using Objetos;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class BDMedicamentos
    {
        string archivo = @"C:\ArchivosTXT\medicamentos.txt";
       
        public void CrearTXT(List<obj_Medicamentos> medicamentos)
        {
            Verify();
            string rutaCarpeta = @"C:\ArchivosTXT";
            string a = Path.Combine(rutaCarpeta, "medicamentos.txt");
            if (File.Exists(a))
            {
                Modificar(medicamentos);
            }
            else
            {
                StringBuilder concatena = new StringBuilder();
                foreach (obj_Medicamentos m in  medicamentos)
                {
                    concatena.Append(m.IdMascota + "," + m.descripcion + "\n");
                }
                File.WriteAllText(a, concatena.ToString());
            }
        }
        public void Modificar(List<obj_Medicamentos> medicamentos)
        {
            string[] lineas = File.ReadAllLines(archivo);

            foreach (obj_Medicamentos e in medicamentos)
            {
                int lineIndex = lineas
                .Select((line, index) => new { line, index })
                .FirstOrDefault(x => x.line.StartsWith(e.IdMascota + ","))
                ?.index ?? -1;

                if (lineIndex != -1)
                {
                    lineas[lineIndex] = $"{e.IdMascota},{e.descripcion}";// Si la línea existe, modificarla
                }
                else
                {
                    lineas = lineas.Append($"{e.IdMascota},{e.descripcion}").ToArray();// Si la línea no existe, agregar una nueva línea al final del archivo
                }
            }
            File.WriteAllLines(archivo, lineas);
        }
        public void Verify()
        {
            string rutaCarpeta = @"C:\ArchivosTXT";
            if (!Directory.Exists(rutaCarpeta))
            {
                Directory.CreateDirectory(rutaCarpeta);
            }
            string archivo = Path.Combine(rutaCarpeta, "medicamentos.txt");
        }
        public void LeerTXT()
        {
            string content = File.ReadAllText(archivo);
            Console.WriteLine(content);
        }
        public List<string> ObtenerDescripcion()
        {
            HashSet<string> descripciones = new HashSet<string>();

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    string[] temp = lineas[i].Split(',');
                    if (!descripciones.Contains(temp[1]))
                    {
                        descripciones.Add(temp[1]);
                    }
                }
            }

            return descripciones.ToList();
        }
        public static string[] ObtenerMascotaPorID(int idMascota)
        {
            if (File.Exists(@"C:\ArchivosTXT\medicamentos.txt"))
            {
                string[] lineas = File.ReadAllLines(@"C:\ArchivosTXT\medicamentos.txt");
                foreach (string linea in lineas)
                {
                    string[] campos = linea.Split(',');
                    if (Convert.ToInt32(campos[0]) == idMascota)
                    {
                        return campos;
                    }
                }
            }
            return null;
        }

    }
}
