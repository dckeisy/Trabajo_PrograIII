﻿using Objetos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class BDMascotas
    {
        string archivo = @"C:\ArchivosTXT\mascotas.txt";

        public void CrearTXT(List<obj_Mascota> mascota)
        {
            Verify();
            string rutaCarpeta = @"C:\ArchivosTXT";
            string a = Path.Combine(rutaCarpeta, "mascotas.txt");
            if (File.Exists(a))
            {
                string nuevoContenido = string.Join("\n", mascota.Select(m => $"{m.idCliente},{m.idMascota},{m.NombreMasc},{m.TipoAnimal},{m.Raza},{m.Peso},{m.Medida}"));
                File.AppendAllText(a, nuevoContenido + "\n");
            }
            else
            {
                StringBuilder concatena = new StringBuilder();
                foreach (obj_Mascota m in mascota)
                {
                    concatena.Append(m.idCliente + "," + m.idMascota + "," + m.NombreMasc + "," + m.TipoAnimal + "," + m.Raza + "," + m.Peso + "," + m.Medida + "\n");
                }
                File.WriteAllText(a, concatena.ToString());
            }
        }
        public void Verify()
        {
            string rutaCarpeta = @"C:\ArchivosTXT";
            if (!Directory.Exists(rutaCarpeta))
            {
                Directory.CreateDirectory(rutaCarpeta);
            }
            string archivo = Path.Combine(rutaCarpeta, "mascotas.txt");
        }

        public void LeerTXT()
        {
            string content = File.ReadAllText(archivo);
            Console.WriteLine(content);
        }
        public List<string> ObtenerID()
        {
            Verify();
            List<string> ids = new List<string>();

            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    String[] temp = lineas[i].Split(',');
                    ids.Add(temp[1]);
                }
            }
            return ids;
        }
        public void Eliminar(string idMascota)
        {

            List<string> nuevaLinea = new List<string>();
            if (File.Exists(archivo))
            {
                string[] lineas = File.ReadAllLines(archivo);
                for (int i = 0; i < lineas.Length; i++)
                {
                    String[] temp = lineas[i].Split(',');
                    if (temp[1] != idMascota)
                    {
                        nuevaLinea.Add(lineas[i]);
                    }
                }
                File.WriteAllLines(archivo, nuevaLinea);
            }
        }

    }
}
