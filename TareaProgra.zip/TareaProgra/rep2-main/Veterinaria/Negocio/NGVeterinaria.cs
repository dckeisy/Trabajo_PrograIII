﻿using System.Collections.Generic;
using Objetos;
using Datos;
using System;

namespace Negocio
{
    public class NGVeterinaria
    {
        //agregar
        public void AgregarClientes(List<obj_Cliente> clientes)
        {
            BDCliente Datos = new BDCliente();
            Datos.CrearTXT(clientes);
        }
        public void AgregarMascotas(List<obj_Mascota> mascotas)
        {
            BDMascotas MascDatos = new BDMascotas();
            MascDatos.CrearTXT(mascotas);
        }
        public void AgregarEnfermedades(List<obj_Enfermedades> enfermedad)
        {
            BDEnfermedades Datos = new BDEnfermedades();
            Datos.CrearTXT(enfermedad);
        }
        public void AgregarMedicamentos(List<obj_Medicamentos> medicamentos)
        {
            BDMedicamentos Datos = new BDMedicamentos();
            Datos.CrearTXT(medicamentos);
        }

        //optener id

        public List<string> ObtenerIDCliente()
        {
            BDCliente Datos = new BDCliente();
            return Datos.ObtenerID();
        }

        public List<string> ObtenerIDMascota()
        {
            BDMascotas Datos = new BDMascotas();
            return Datos.ObtenerID();
        }

        //eliminar datos
        public void EliminarCliente(string idCliente)
        {
            BDCliente Datos = new BDCliente();
            Datos.Eliminar(idCliente);
        }
        public void EliminarMascota(string idMascota)
        {
            BDMascotas Datos = new BDMascotas();
            Datos.Eliminar(idMascota);
        }
        //reportes
        //------------------------------------------
        public List<string> OptenerDescripEnf()
        {
            BDEnfermedades Datos = new BDEnfermedades();
            return Datos.ObtenerDescripcion();
        }
        //-------------------------------------------
        public string ObtenerDatosMascotaEn(int idMascota)
        {
            String enfermedades = "";

            string[] mascota = BDEnfermedades.ObtenerMascotaPorID(idMascota);

            if (mascota != null)
            {
                for (int i = 1; i < mascota.Length; i++)
                {
                    if (enfermedades == "")
                    {
                        enfermedades = mascota[i];
                    }
                    else
                    {
                        enfermedades = enfermedades + "," + mascota[i];
                    }
                }
            }
            return enfermedades;
        }
        //------------------------------------------
        public string ObtenerDatosMascotaMe(int idMascota)
        {
            String medicamentos = "";

            string[] mascota = BDMedicamentos.ObtenerMascotaPorID(idMascota);

            if (mascota != null)
            {
                for (int i = 1; i < mascota.Length; i++)
                {
                    if (medicamentos == "")
                    {
                        medicamentos = mascota[i];
                    }
                    else
                    {
                        medicamentos = medicamentos + "," + mascota[i];
                    }
                }
            }
            return medicamentos;
        }
        //--------------------------------------------
        public List<string> OptenerDescripMedi()
        {
            BDMedicamentos Datos = new BDMedicamentos();
            return Datos.ObtenerDescripcion();
        }
        //----------------------------------------------
        public static string ObtenerEnfermedadesComunes(int idMascota1, int idMascota2)
        {
            String enfermedadesComunes = "";

            string[] mascota1 = BDEnfermedades.ObtenerMascotaPorID(idMascota1);

            string[] mascota2 = BDEnfermedades.ObtenerMascotaPorID(idMascota2);
            if (mascota1 != null & mascota2 != null)
            {
                for (int i = 0; i < mascota1.Length; i++)
                {
                    for (int j = 0; j < mascota2.Length; j++)
                    {
                        if (mascota1[i] == mascota2[j])
                        {
                            if (enfermedadesComunes == "")
                            {
                                enfermedadesComunes = mascota1[i];
                            }
                            else
                            {
                                enfermedadesComunes = enfermedadesComunes + "," + mascota1[i];
                            }
                        }
                    }
                }
            }
            return enfermedadesComunes;

        }

        public static String ObtenerMedicamentosComunes(int idMascota1, int idMascota2)
        {
            string medicamentosComunes = "";

            string[] mascota1 = BDMedicamentos.ObtenerMascotaPorID(idMascota1);

            string[] mascota2 = BDMedicamentos.ObtenerMascotaPorID(idMascota2);
            if (mascota1 != null & mascota2 != null)
            {
                for (int i = 1; i < mascota1.Length; i++)
                {
                    for (int j = 1; j < mascota2.Length; j++)
                    {
                        if (mascota1[i] == mascota2[j])
                        {
                            if (medicamentosComunes == "")
                            {
                                medicamentosComunes = mascota1[i];
                            }
                            else
                            {
                                medicamentosComunes = medicamentosComunes + "," + mascota1[i];
                            }
                        }
                    }
                }
            }
            return medicamentosComunes;
        }
    }
}

