﻿using Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocio;
using System.IO;

namespace Veterinaria
{
    public partial class Client : Form
    {
        NGVeterinaria negocio = new NGVeterinaria();

        obj_Cliente c = new obj_Cliente();
        public Client()
        {

            InitializeComponent();
            llenarCombo();
            MostrarClientes();


        }

        public void llenarCombo()
        {
            comID.Items.Clear();
            List<string> ids = negocio.ObtenerIDCliente();
            if(ids !=null )
            {
                for(int i = 0; i < ids.Count; i++)
                {
                    comID.Items.Add(ids[i]);
                }
            }
            
        }

        private void btnInsertar_MouseClick(object sender, MouseEventArgs e)
        {
            String cedula = txtCedula.Text;
            String nombre = txtNombre.Text;
            String apellidos = txtApellido.Text;
            String direccion = txtDireccion.Text;
            String telefono = txtTelefono.Text;
            c.clientes.Add(new obj_Cliente
            {
                Identificacion = cedula,
                Nombre = nombre,
                Apellidos = apellidos,
                Telefono = telefono,
                Direccion = direccion
            });
            negocio.AgregarClientes(c.clientes);
            llenarCombo();
            MostrarClientes();
            View_Main ventana = new View_Main();
            ventana.Show();

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            String idCliente = comID.SelectedItem.ToString();
            if(idCliente != "" & idCliente != null)
            {
                negocio.EliminarCliente(idCliente);
            }
            MostrarClientes();
        }
        private void MostrarClientes()
        {
            if (File.Exists(@"C:\ArchivosTXT\clientes.txt"))
            {
                string[] lines = File.ReadAllLines(@"C:\ArchivosTXT\clientes.txt");
                dataGridView1.Rows.Clear();
                foreach (string line in lines)
                {
                    string[] data = line.Split(',');
                    dataGridView1.Rows.Add(data);
                }
            }
        }

        private void Client_Load(object sender, EventArgs e)
        {

        }
    }
}
