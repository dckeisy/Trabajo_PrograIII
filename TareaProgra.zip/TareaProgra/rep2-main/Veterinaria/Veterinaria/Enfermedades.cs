﻿using Negocio;
using Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class Enfermedades : Form
    {
        NGVeterinaria n = new NGVeterinaria();
        obj_Enfermedades en = new obj_Enfermedades();
        public Enfermedades()
        {
            InitializeComponent();
            llenarCombo();
            
        }

        public void llenarCombo()
        {
            comID.Items.Clear();
            List<string> ids = new List<string>();
            ids = n.ObtenerIDMascota();
            for (int i = 0; i < ids.Count; i++)
            {
                comID.Items.Add(ids[i]);
            }

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            en.enfermedades = new List<obj_Enfermedades> ();
            String idMascota = comID.SelectedItem.ToString();
            if (idMascota != "" & idMascota != null & txtDatosMascota.Text != "")
            {
                en.enfermedades.Add(new obj_Enfermedades

                {
                    IdMascota = Convert.ToInt32(idMascota),
                    descripcion = txtDatosMascota.Text
                });
                n.AgregarEnfermedades(en.enfermedades);
            }
        }

        private void comID_SelectedIndexChanged(object sender, EventArgs e)
        {
            string idMascota = comID.SelectedItem.ToString();
            if (idMascota != "")
            {
                txtDatosMascota.Text = n.ObtenerDatosMascotaEn(Convert.ToInt32(idMascota));
            }
        }

        private void Enfermedades_Load(object sender, EventArgs e)
        {

        }
    }
}
