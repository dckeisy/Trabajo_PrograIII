﻿using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class Rep_medicamentos : Form
    {
        NGVeterinaria n = new NGVeterinaria();
        public Rep_medicamentos()
        {
            InitializeComponent();
            llenarTXT();
        }
        public void llenarTXT()
        {
            List<string> list = new List<string>();
            list = n.OptenerDescripMedi();
            string enfermedades = "";
            foreach (string s in list)
            {
                enfermedades += s + "\n";
            }
            txt.Text = enfermedades;
        }
    }
}
