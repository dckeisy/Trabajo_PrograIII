﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Objetos;

namespace Veterinaria
{
    public partial class View_Main : Form
    {
        private void AbrirFH(object formHijo)
        {
            if (this.pContenedor.Controls.Count > 0) 
            {
                this.pContenedor.Controls.RemoveAt(0);
            }

            Form fh = formHijo as Form; 
            
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill; 
            this.pContenedor.Controls.Add(fh); 
            this.pContenedor.Tag = fh; 
            fh.Show(); 
        }

        public View_Main()
        {
            InitializeComponent();

        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            pMenu_rep.Visible = true;
        }

        private void btn_rep_enf_tra_Click(object sender, EventArgs e)
        {
            pMenu_rep.Visible = false;
            AbrirFH(new Rep_enfermedades());
        }

        private void btn_rep_med_entre_Click(object sender, EventArgs e)
        {
            pMenu_rep.Visible = false;
            AbrirFH(new Rep_medicamentos());
        }

        private void btn_rep_com_masc_Click(object sender, EventArgs e)
        {
            pMenu_rep.Visible = false;
            AbrirFH(new Rep_comMascotas());
        }

        private void btnCRUD_client_Click(object sender, EventArgs e)
        {
            AbrirFH(new Client());

        }

        private void btnCRUD_mascota_Click(object sender, EventArgs e)
        {
            AbrirFH(new Mascotas());
        }

        private void btnCRUD_enfer_Click(object sender, EventArgs e)
        {
            AbrirFH(new Enfermedades());
        }

        private void btnCRUD_medica_Click(object sender, EventArgs e)
        {
            AbrirFH(new Medicamentos());
        }
    }
}
