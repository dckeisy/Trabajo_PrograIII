﻿using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class Rep_enfermedades : Form
    {
        NGVeterinaria n = new NGVeterinaria();
        public Rep_enfermedades()
        {
            InitializeComponent();
            llenarTXT();
        }
        public void llenarTXT()
        {
            List<string> list = new List<string>();
            list = n.OptenerDescripEnf();
            string enfermedades = "";
            foreach (string s in list)
            {
                enfermedades += s + "\n";
            }
            txt.Text = enfermedades;
        }

        private void Rep_enfermedades_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
