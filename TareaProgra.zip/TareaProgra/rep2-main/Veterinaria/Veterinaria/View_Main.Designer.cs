﻿namespace Veterinaria
{
    partial class View_Main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(View_Main));
            this.pMenu = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.pSubmenu = new System.Windows.Forms.Panel();
            this.pMenu_rep = new System.Windows.Forms.Panel();
            this.btn_rep_com_masc = new System.Windows.Forms.Button();
            this.btn_rep_med_entre = new System.Windows.Forms.Button();
            this.btn_rep_enf_tra = new System.Windows.Forms.Button();
            this.btnReportes = new System.Windows.Forms.Button();
            this.btnCRUD_medica = new System.Windows.Forms.Button();
            this.btnCRUD_enfer = new System.Windows.Forms.Button();
            this.btnCRUD_mascota = new System.Windows.Forms.Button();
            this.btnCRUD_client = new System.Windows.Forms.Button();
            this.pContenedor = new System.Windows.Forms.Panel();
            this.pMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            this.pSubmenu.SuspendLayout();
            this.pMenu_rep.SuspendLayout();
            this.SuspendLayout();
            // 
            // pMenu
            // 
            this.pMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(3)))), ((int)(((byte)(60)))));
            this.pMenu.Controls.Add(this.btnCerrar);
            this.pMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pMenu.Location = new System.Drawing.Point(0, 0);
            this.pMenu.Name = "pMenu";
            this.pMenu.Size = new System.Drawing.Size(1272, 35);
            this.pMenu.TabIndex = 0;
            // 
            // btnCerrar
            // 
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(1237, 0);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(35, 35);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCerrar.TabIndex = 0;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // pSubmenu
            // 
            this.pSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.pSubmenu.Controls.Add(this.pMenu_rep);
            this.pSubmenu.Controls.Add(this.btnReportes);
            this.pSubmenu.Controls.Add(this.btnCRUD_medica);
            this.pSubmenu.Controls.Add(this.btnCRUD_enfer);
            this.pSubmenu.Controls.Add(this.btnCRUD_mascota);
            this.pSubmenu.Controls.Add(this.btnCRUD_client);
            this.pSubmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pSubmenu.Location = new System.Drawing.Point(0, 35);
            this.pSubmenu.Name = "pSubmenu";
            this.pSubmenu.Size = new System.Drawing.Size(265, 604);
            this.pSubmenu.TabIndex = 1;
            // 
            // pMenu_rep
            // 
            this.pMenu_rep.Controls.Add(this.btn_rep_com_masc);
            this.pMenu_rep.Controls.Add(this.btn_rep_med_entre);
            this.pMenu_rep.Controls.Add(this.btn_rep_enf_tra);
            this.pMenu_rep.Location = new System.Drawing.Point(64, 403);
            this.pMenu_rep.Name = "pMenu_rep";
            this.pMenu_rep.Size = new System.Drawing.Size(200, 189);
            this.pMenu_rep.TabIndex = 5;
            this.pMenu_rep.Visible = false;
            // 
            // btn_rep_com_masc
            // 
            this.btn_rep_com_masc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_rep_com_masc.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_rep_com_masc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_rep_com_masc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rep_com_masc.Font = new System.Drawing.Font("Malgun Gothic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rep_com_masc.Location = new System.Drawing.Point(1, 111);
            this.btn_rep_com_masc.Name = "btn_rep_com_masc";
            this.btn_rep_com_masc.Size = new System.Drawing.Size(200, 39);
            this.btn_rep_com_masc.TabIndex = 3;
            this.btn_rep_com_masc.Text = "Comparar mascotas";
            this.btn_rep_com_masc.UseVisualStyleBackColor = true;
            this.btn_rep_com_masc.Click += new System.EventHandler(this.btn_rep_com_masc_Click);
            // 
            // btn_rep_med_entre
            // 
            this.btn_rep_med_entre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_rep_med_entre.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_rep_med_entre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_rep_med_entre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rep_med_entre.Font = new System.Drawing.Font("Malgun Gothic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rep_med_entre.Location = new System.Drawing.Point(0, 54);
            this.btn_rep_med_entre.Name = "btn_rep_med_entre";
            this.btn_rep_med_entre.Size = new System.Drawing.Size(200, 51);
            this.btn_rep_med_entre.TabIndex = 2;
            this.btn_rep_med_entre.Text = "Medicamentos entregados";
            this.btn_rep_med_entre.UseVisualStyleBackColor = true;
            this.btn_rep_med_entre.Click += new System.EventHandler(this.btn_rep_med_entre_Click);
            // 
            // btn_rep_enf_tra
            // 
            this.btn_rep_enf_tra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_rep_enf_tra.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_rep_enf_tra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_rep_enf_tra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rep_enf_tra.Font = new System.Drawing.Font("Malgun Gothic", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rep_enf_tra.Location = new System.Drawing.Point(0, 0);
            this.btn_rep_enf_tra.Name = "btn_rep_enf_tra";
            this.btn_rep_enf_tra.Size = new System.Drawing.Size(200, 48);
            this.btn_rep_enf_tra.TabIndex = 1;
            this.btn_rep_enf_tra.Text = "Enfermedades tratadas";
            this.btn_rep_enf_tra.UseVisualStyleBackColor = true;
            this.btn_rep_enf_tra.Click += new System.EventHandler(this.btn_rep_enf_tra_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReportes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnReportes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportes.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportes.Location = new System.Drawing.Point(0, 349);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(265, 48);
            this.btnReportes.TabIndex = 4;
            this.btnReportes.Text = "Reportes";
            this.btnReportes.UseVisualStyleBackColor = true;
            this.btnReportes.Click += new System.EventHandler(this.btnReportes_Click);
            // 
            // btnCRUD_medica
            // 
            this.btnCRUD_medica.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCRUD_medica.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnCRUD_medica.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCRUD_medica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCRUD_medica.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRUD_medica.Location = new System.Drawing.Point(0, 295);
            this.btnCRUD_medica.Name = "btnCRUD_medica";
            this.btnCRUD_medica.Size = new System.Drawing.Size(265, 48);
            this.btnCRUD_medica.TabIndex = 3;
            this.btnCRUD_medica.Text = "Medicamentos";
            this.btnCRUD_medica.UseVisualStyleBackColor = true;
            this.btnCRUD_medica.Click += new System.EventHandler(this.btnCRUD_medica_Click);
            // 
            // btnCRUD_enfer
            // 
            this.btnCRUD_enfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCRUD_enfer.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnCRUD_enfer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCRUD_enfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCRUD_enfer.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRUD_enfer.Location = new System.Drawing.Point(0, 241);
            this.btnCRUD_enfer.Name = "btnCRUD_enfer";
            this.btnCRUD_enfer.Size = new System.Drawing.Size(264, 48);
            this.btnCRUD_enfer.TabIndex = 2;
            this.btnCRUD_enfer.Text = "Enfermedades";
            this.btnCRUD_enfer.UseVisualStyleBackColor = true;
            this.btnCRUD_enfer.Click += new System.EventHandler(this.btnCRUD_enfer_Click);
            // 
            // btnCRUD_mascota
            // 
            this.btnCRUD_mascota.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCRUD_mascota.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnCRUD_mascota.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCRUD_mascota.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCRUD_mascota.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRUD_mascota.Location = new System.Drawing.Point(0, 187);
            this.btnCRUD_mascota.Name = "btnCRUD_mascota";
            this.btnCRUD_mascota.Size = new System.Drawing.Size(262, 48);
            this.btnCRUD_mascota.TabIndex = 1;
            this.btnCRUD_mascota.Text = "CRUD Mascota";
            this.btnCRUD_mascota.UseVisualStyleBackColor = true;
            this.btnCRUD_mascota.Click += new System.EventHandler(this.btnCRUD_mascota_Click);
            // 
            // btnCRUD_client
            // 
            this.btnCRUD_client.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCRUD_client.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnCRUD_client.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCRUD_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCRUD_client.Font = new System.Drawing.Font("Malgun Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCRUD_client.Location = new System.Drawing.Point(0, 133);
            this.btnCRUD_client.Name = "btnCRUD_client";
            this.btnCRUD_client.Size = new System.Drawing.Size(265, 48);
            this.btnCRUD_client.TabIndex = 0;
            this.btnCRUD_client.Text = "CRUD Cliente";
            this.btnCRUD_client.UseVisualStyleBackColor = true;
            this.btnCRUD_client.Click += new System.EventHandler(this.btnCRUD_client_Click);
            // 
            // pContenedor
            // 
            this.pContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pContenedor.Location = new System.Drawing.Point(265, 35);
            this.pContenedor.Name = "pContenedor";
            this.pContenedor.Size = new System.Drawing.Size(1007, 604);
            this.pContenedor.TabIndex = 2;
            // 
            // View_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 639);
            this.Controls.Add(this.pContenedor);
            this.Controls.Add(this.pSubmenu);
            this.Controls.Add(this.pMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "View_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.pMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            this.pSubmenu.ResumeLayout(false);
            this.pMenu_rep.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pMenu;
        private System.Windows.Forms.Panel pSubmenu;
        private System.Windows.Forms.Button btnCRUD_client;
        private System.Windows.Forms.Button btnReportes;
        private System.Windows.Forms.Button btnCRUD_medica;
        private System.Windows.Forms.Button btnCRUD_enfer;
        private System.Windows.Forms.Button btnCRUD_mascota;
        private System.Windows.Forms.Panel pMenu_rep;
        private System.Windows.Forms.Button btn_rep_enf_tra;
        private System.Windows.Forms.Button btn_rep_med_entre;
        private System.Windows.Forms.Button btn_rep_com_masc;
        private System.Windows.Forms.PictureBox btnCerrar;
        private System.Windows.Forms.Panel pContenedor;
    }
}

