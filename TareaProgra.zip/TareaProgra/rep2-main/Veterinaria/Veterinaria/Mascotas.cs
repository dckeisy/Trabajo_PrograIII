﻿using Negocio;
using Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class Mascotas : Form
    {
        obj_Mascota m = new obj_Mascota();
        NGVeterinaria negocio = new NGVeterinaria();
        public Mascotas()
        {
            InitializeComponent();
            llenarCombo();
            MostrarMascotas();


        }
        public void llenarCombo()
        {
            comID.Items.Clear();
            List<string> ids = negocio.ObtenerIDCliente();
            if (ids != null)
            {
                for (int i = 0; i < ids.Count; i++)
                {
                    comID.Items.Add(ids[i]);
                }
            }

        }

        private void Mascotas_Load(object sender, EventArgs e)
        {

        }

        private void btnInsertar_MouseClick(object sender, MouseEventArgs e)
        {
            int idCliente = Convert.ToInt32(txtIdDueno.Text);
            int idMascota = Convert.ToInt32(txtIdMascota.Text);
            String nombre = txtNombre.Text;
            String tipoAnimal = txtTipoAnimal.Text;
            String raza = txtRaza.Text;
            double peso = Convert.ToDouble(txtPeso.Text);
            double medida = Convert.ToDouble(txtMedida.Text);
            m.mascotas.Add(new obj_Mascota
            {
                idCliente = idCliente,
                idMascota = idMascota,
                NombreMasc = nombre,
                TipoAnimal = tipoAnimal,
                Raza = raza,
                Peso = peso,
                Medida = medida
            });
            negocio.AgregarMascotas(m.mascotas);
            llenarCombo();
            MostrarMascotas();
            View_Main ventana = new View_Main();
            ventana.Show();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            String idMascota = comID.SelectedItem.ToString();
            if (idMascota != "" & idMascota != null)
            {
                negocio.EliminarMascota(idMascota);
            }
            MostrarMascotas();
        }
        private void MostrarMascotas()
        {
            if (File.Exists(@"C:\ArchivosTXT\mascotas.txt"))
            {
                string[] lines = File.ReadAllLines(@"C:\ArchivosTXT\mascotas.txt");
                dataGridView1.Rows.Clear();
                foreach (string line in lines)
                {
                    string[] data = line.Split(',');
                    dataGridView1.Rows.Add(data);
                }
            }
        }
    }
}
