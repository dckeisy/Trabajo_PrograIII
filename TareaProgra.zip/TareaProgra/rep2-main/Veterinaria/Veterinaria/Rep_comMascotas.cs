﻿using Negocio;
using Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Veterinaria
{
    public partial class Rep_comMascotas : Form
    {
        NGVeterinaria negocio = new NGVeterinaria();
        public Rep_comMascotas()
        {
            InitializeComponent();
            cmbMascota1.DataSource = negocio.ObtenerIDMascota();
            cmbMascota2.DataSource = negocio.ObtenerIDMascota();
        }

        private void Rep_comMascotas_Load(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            int idMascota1 = Convert.ToInt32(cmbMascota1.SelectedItem.ToString());
            int idMascota2 = Convert.ToInt32(cmbMascota2.SelectedItem.ToString());

            txtEnfCom.Text = NGVeterinaria.ObtenerEnfermedadesComunes(idMascota1, idMascota2);
            txtMedCom.Text = NGVeterinaria.ObtenerMedicamentosComunes(idMascota1, idMascota2);
        }
    }
}
