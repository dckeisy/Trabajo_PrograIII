﻿using Negocio;
using Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Veterinaria
{
    public partial class Medicamentos : Form
    {
        NGVeterinaria negocio = new NGVeterinaria();
        obj_Medicamentos m = new obj_Medicamentos();
        public Medicamentos()
        {
            InitializeComponent();
            llenarCombo();
        }
        public void llenarCombo()
        {
            comID.Items.Clear();
            List<string> ids = new List<string>();
            ids = negocio.ObtenerIDMascota();
            for (int i = 0; i < ids.Count; i++)
            {
                comID.Items.Add(ids[i]);
            }

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            m.medicamentos = new List<obj_Medicamentos>();
            String idMascota = comID.SelectedItem.ToString();
            
            if (idMascota != "" & idMascota != null & txtEditor.Text != "")
            {
                m.medicamentos.Add(new obj_Medicamentos
                {
                    IdMascota = Convert.ToInt32(idMascota),
                    descripcion = txtEditor.Text
                });
                negocio.AgregarMedicamentos(m.medicamentos);
                View_Main ventana = new View_Main();
                ventana.Show();
            }
        }

        private void comID_SelectedIndexChanged(object sender, EventArgs e)
        {
            String idMascota = comID.SelectedItem.ToString();
            if (idMascota != "" & idMascota != null)
            {
                txtEditor.Text = negocio.ObtenerDatosMascotaMe(int.Parse(idMascota));
            }
        }
    }
}
